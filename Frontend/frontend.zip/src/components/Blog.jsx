import React from 'react';

function Blog() {
  return (
    <div>
      <br></br><br></br><br></br>
<br></br><br></br><br></br>
<br></br><br></br><br></br>
    <div className="container2">
      <center><h2><a href="https://bxc6215.uta.cloud/web/uncategorized/web-data-management-blog/">Click here for Blog Content</a></h2></center>
      <br/>
   </div>
   </div>
  );
}

export default Blog;
